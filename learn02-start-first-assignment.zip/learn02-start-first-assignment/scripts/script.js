function myFunction2() {
    document.getElementById("sample").innerHTML = 
    "Changed from a function in the head section";
}

// single line comment
/* Block comment
block comment
*/
